#!/usr/bin/env python3
"""
Flier for Code Less Traveled. Half sheet (5.5 x 8.5in), one side.

Print, not screen. The site's vellum sheets are translucent over a live
terrain and none of that survives a laser printer, so the construction
here is flat: solid tint panels, contours dropped to a tint that stays
out of the type's way, no blur anywhere. Palette, wordmark and fork are
still the site's, read out of styles.css and main.js.

Outputs:
  flier.pdf         5.5 x 8.5 with 0.125in bleed, for a print shop
  flier-2up.pdf     two per US Letter with cut marks, for printing at home
  flier-preview.png what it looks like

    python3 make_flier.py
"""

import os
import qrcode
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.misc.transform import Transform
import cairosvg
import re

HERE = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(HERE, "work", "The One That Works")
FONTS = os.path.join(HERE, "fonts")

DPI = 300
IN = float(DPI)
TRIM_W, TRIM_H = 5.5 * IN, 8.5 * IN
BLEED = 0.125 * IN
W, H = TRIM_W + 2 * BLEED, TRIM_H + 2 * BLEED
MARGIN = 0.45 * IN                      # safe area inside the trim

# ---- palette, from :root --------------------------------------------
PAPER = "#f4efe3"
PAPER2 = "#ebe4d4"
INK = "#241f18"
SOFT = "#474339"
CONTOUR = "#c2a878"
RED = "#a50e14"
RULE = "#d6cbb4"

F800 = TTFont(os.path.join(FONTS, "arch-800-92.ttf"))
F600 = TTFont(os.path.join(FONTS, "arch-600-92.ttf"))
F400 = TTFont(os.path.join(FONTS, "arch-400-92.ttf"))
FBOD = TTFont(os.path.join(FONTS, "literata-400.ttf"))
FMON = TTFont(os.path.join(FONTS, "plexmono.ttf"))

PT = DPI / 72.0                          # points to device px
TRACK = -0.025
RUN, FORK_TRIM = 1.6, 0.86

SITE_URL = "https://codelesstraveled.com"
EMAIL = "hello@codelesstraveled.com"


def paths(font, text, size, x, y, fill, track=0.0):
    upm = font["head"].unitsPerEm
    gs, cm, hm = font.getGlyphSet(), font.getBestCmap(), font["hmtx"]
    s = size / upm
    out, pen = [], 0.0
    for ch in text:
        gn = cm.get(ord(ch))
        if gn is None:
            pen += 0.4 * size
            continue
        spp = SVGPathPen(gs)
        gs[gn].draw(TransformPen(spp, Transform(s, 0, 0, -s, x + pen, y)))
        d = spp.getCommands()
        if d:
            out.append(f'<path d="{d}"/>')
        pen += hm[gn][0] * s + track * size
    return f'<g fill="{fill}">' + "".join(out) + "</g>", pen


def wide(font, text, size, track=0.0):
    upm = font["head"].unitsPerEm
    cm, hm = font.getBestCmap(), font["hmtx"]
    return sum((hm[cm[ord(c)]][0] * size / upm if ord(c) in cm else 0.4 * size)
               + track * size for c in text)


def wrap(font, text, size, maxw, track=0.0):
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if wide(font, t, size, track) <= maxw or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def fork(size, x, y):
    """main.js's geometry, resolved at build time."""
    f = F800
    upm = f["head"].unitsPerEm
    gs, cm, hm = f.getGlyphSet(), f.getBestCmap(), f["hmtx"]

    def bb(ch):
        bp = BoundsPen(gs)
        gs[cm[ord(ch)]].draw(bp)
        return bp.bounds

    bl, bx = bb("l"), bb("x")
    s = size / upm
    left, stem, asc, xh = bl[0] * s, (bl[2] - bl[0]) * s, bl[3] * s, bx[3] * s
    assert 0.06 * size < stem < 0.22 * size, "stem out of range; see main.js"
    w = stem * FORK_TRIM
    cx = x + left + stem / 2
    ex = cx - (asc - xh) * RUN
    return (f'<g fill="none" stroke-width="{w:.2f}">'
            f'<path d="M{cx:.2f} {y-xh:.2f} L{cx:.2f} {y-asc:.2f}" stroke="{RULE}"/>'
            f'<path d="M{cx:.2f} {y:.2f} L{cx:.2f} {y-xh:.2f} L{ex:.2f} {y-asc:.2f}" '
            f'stroke="{RED}" stroke-linejoin="round" stroke-linecap="butt"/></g>',
            hm[cm[ord("l")]][0] * s)


def wordmark(size, cx, base):
    w = (wide(F800, "Code", size, TRACK) + wide(F800, "l", size, TRACK)
         + wide(F400, "ess", size, TRACK) + wide(F800, "traveled", size, TRACK))
    x = cx - w / 2
    out = []
    g, a = paths(F800, "Code", size, x, base, INK, TRACK); out.append(g); x += a
    g, a = fork(size, x, base); out.append(g); x += a + TRACK * size
    x += -2 * (size / 84)
    g, a = paths(F400, "ess", size, x, base, SOFT, TRACK); out.append(g); x += a
    g, a = paths(F800, "traveled", size, x, base, INK, TRACK); out.append(g)
    return "".join(out), w


def terrain(op):
    """The site's own contours, dropped to a tint so type stays crisp."""
    src = open(os.path.join(SITE, "contours.svg")).read()
    body = re.sub(r"^.*?<svg[^>]*>", "", src, flags=re.S).replace("</svg>", "")
    body = body.replace('stroke="currentColor"', f'stroke="{CONTOUR}"')
    return (f'<g opacity="{op}"><svg x="0" y="0" width="{W:.0f}" height="{H:.0f}" '
            f'viewBox="0 0 1572 924" fill="none" preserveAspectRatio="xMidYMid slice">'
            f'{body}</svg></g>')


def qr(data, x, y, size):
    q = qrcode.QRCode(border=0, error_correction=qrcode.constants.ERROR_CORRECT_M)
    q.add_data(data)
    q.make(fit=True)
    m = q.get_matrix()
    n = len(m)
    c = size / n
    r = "".join(f'<rect x="{x+j*c:.2f}" y="{y+i*c:.2f}" width="{c:.2f}" '
                f'height="{c:.2f}"/>'
                for i, row in enumerate(m) for j, v in enumerate(row) if v)
    return f'<g fill="{INK}" shape-rendering="crispEdges">{r}</g>'


# =====================================================================
p = []
L = BLEED + MARGIN                       # left safe edge
R = W - BLEED - MARGIN                   # right safe edge
CW = R - L                               # content width
CX = W / 2

p.append(f'<rect width="{W:.0f}" height="{H:.0f}" fill="{PAPER}"/>')
p.append(terrain(0.28))

# --- masthead ---------------------------------------------------------
y = BLEED + 0.56 * IN
lbl, lw = paths(F800, "WEB DEVELOPMENT", 9 * PT, L, y, SOFT, track=0.13)
p.append(lbl)
cd = "41.8203\u00b0 N  88.1734\u00b0 W"
p.append(paths(FMON, cd, 8.5 * PT, R - wide(FMON, cd, 8.5 * PT), y, SOFT)[0])
p.append(f'<line x1="{L}" y1="{y+0.12*IN:.0f}" x2="{R}" y2="{y+0.12*IN:.0f}" '
         f'stroke="{RULE}" stroke-width="2"/>')

# --- wordmark ---------------------------------------------------------
g, _ = wordmark(0.46 * IN, CX, BLEED + 1.46 * IN)
p.append(g)

# --- the hook ---------------------------------------------------------
y = BLEED + 2.04 * IN
hook = ("Most small business websites are rented. I'm one person in "
        "DuPage County who will build you one you own.")
for i, ln in enumerate(wrap(FBOD, hook, 13 * PT, CW - 0.3 * IN)):
    p.append(paths(FBOD, ln, 13 * PT, L, y + i * 0.245 * IN, INK)[0])

# --- what I build -----------------------------------------------------
y = BLEED + 3.16 * IN
p.append(f'<line x1="{L}" y1="{y-0.22*IN:.0f}" x2="{R}" y2="{y-0.22*IN:.0f}" '
         f'stroke="{RULE}" stroke-width="2"/>')
p.append(paths(F800, "WHAT I BUILD", 9 * PT, L, y, SOFT, track=0.13)[0])

items = [
    ("Websites", "Yours outright. No platform, no monthly fee, nothing to patch."),
    ("Web applications", "Booking, inventory, accounts, internal tools."),
    ("Slow or broken sites", "I find what's actually wrong and tell you plainly."),
    ("Identity and print", "Logos, cards, signage. Usually alongside a site."),
]
y += 0.26 * IN
for name, desc in items:
    p.append(f'<circle cx="{L+5:.0f}" cy="{y-0.04*IN:.0f}" r="4" fill="{RED}"/>')
    p.append(paths(F600, name, 10.5 * PT, L + 0.18 * IN, y, INK, -0.01)[0])
    p.append(paths(FBOD, desc, 9.5 * PT, L + 0.18 * IN, y + 0.155 * IN, SOFT)[0])
    y += 0.40 * IN

# --- prices -----------------------------------------------------------
y = BLEED + 4.92 * IN
PH = 1.36 * IN
p.append(f'<rect x="{L}" y="{y:.0f}" width="{CW:.0f}" height="{PH:.0f}" '
         f'fill="{PAPER2}"/>')
p.append(f'<rect x="{L}.5" y="{y:.0f}.5" width="{CW-1:.0f}" height="{PH-1:.0f}" '
         f'fill="none" stroke="{RULE}" stroke-width="2"/>')
p.append(paths(F800, "SCALE OF CHARGES", 8.5 * PT, L + 0.16 * IN,
               y + 0.25 * IN, SOFT, track=0.13)[0])

rows = [("The survey", "A written report on what you've got", "$1,200"),
        ("The build", "Up to six pages, yours to keep", "from $5,000"),
        ("Changes later", "Billed by the hour, most months nothing", "$150 / hr")]
ry = y + 0.53 * IN
for name, desc, amt in rows:
    p.append(paths(F600, name, 10 * PT, L + 0.16 * IN, ry, INK, -0.01)[0])
    p.append(paths(FBOD, desc, 8.5 * PT, L + 1.15 * IN, ry, SOFT)[0])
    aw = wide(FMON, amt, 9.5 * PT)
    p.append(paths(FMON, amt, 9.5 * PT, R - 0.16 * IN - aw, ry, INK)[0])
    ry += 0.28 * IN

# --- the offer --------------------------------------------------------
# The only thing on the sheet with a reason to keep it, so it gets the
# red: the one colour the site spends on the road actually taken.
y = BLEED + 6.52 * IN
OH = 0.62 * IN
p.append(f'<rect x="{L}" y="{y:.0f}" width="{0.055*IN:.0f}" height="{OH:.0f}" '
         f'fill="{RED}"/>')
ox = L + 0.055 * IN + 0.16 * IN
p.append(paths(F800, "FREE, FIRST TEN, THROUGH 30 SEPTEMBER", 8.5 * PT, ox,
               y + 0.17 * IN, RED, track=0.11)[0])
offer = ("Mention the expo and I'll send you a one-page read on your "
         "current site, with the numbers behind it.")
for i, ln in enumerate(wrap(FBOD, offer, 10 * PT, R - ox)):
    p.append(paths(FBOD, ln, 10 * PT, ox, y + 0.38 * IN + i * 0.185 * IN, INK)[0])

# --- contact ----------------------------------------------------------
y = BLEED + 7.20 * IN
QS = 0.80 * IN
p.append(qr(SITE_URL, R - QS, y, QS))
p.append(paths(F800, "ONE PERSON. WARRENVILLE, IL.", 9 * PT, L, y + 0.14 * IN,
               SOFT, track=0.1)[0])
p.append(paths(F600, "codelesstraveled.com", 13 * PT, L, y + 0.43 * IN, INK, -0.01)[0])
p.append(paths(FBOD, EMAIL, 10 * PT, L, y + 0.70 * IN, SOFT)[0])

svg = (f'<svg xmlns="http://www.w3.org/2000/svg" '
       f'width="{W/IN:.4f}in" height="{H/IN:.4f}in" '
       f'viewBox="0 0 {W:.0f} {H:.0f}">' + "".join(p) + "</svg>")

open(os.path.join(HERE, "flier.svg"), "w").write(svg)
cairosvg.svg2pdf(bytestring=svg.encode(), write_to=os.path.join(HERE, "flier.pdf"))
cairosvg.svg2png(bytestring=svg.encode(),
                 write_to=os.path.join(HERE, "flier-preview.png"),
                 output_width=W, output_height=H)

# --- 2-up on US Letter, for printing at home --------------------------
LW, LH = 8.5 * IN, 11 * IN
ox, oy = (LW - TRIM_W) / 2, (LH - 2 * TRIM_H) / 2
inner = svg.replace('<svg xmlns="http://www.w3.org/2000/svg"', '<svg')
one = (f'<svg x="0" y="0" width="{TRIM_W:.0f}" height="{TRIM_H:.0f}" '
       f'viewBox="{BLEED:.0f} {BLEED:.0f} {TRIM_W:.0f} {TRIM_H:.0f}">'
       + "".join(p) + "</svg>")
marks = "".join(
    f'<line x1="{a}" y1="{b}" x2="{c}" y2="{d}" stroke="#999" stroke-width="1"/>'
    for a, b, c, d in [
        (ox - 18, oy + TRIM_H, ox - 4, oy + TRIM_H),
        (ox + TRIM_W + 4, oy + TRIM_H, ox + TRIM_W + 18, oy + TRIM_H)])
up = (f'<svg xmlns="http://www.w3.org/2000/svg" '
      f'width="{LW/IN:.4f}in" height="{LH/IN:.4f}in" '
      f'viewBox="0 0 {LW:.0f} {LH:.0f}"><rect width="{LW:.0f}" height="{LH:.0f}" '
      f'fill="#ffffff"/>'
      f'<g transform="translate({ox:.0f},{oy:.0f})">{one}</g>'
      f'<g transform="translate({ox:.0f},{oy+TRIM_H:.0f})">{one}</g>'
      f'{marks}</svg>')
cairosvg.svg2pdf(bytestring=up.encode(),
                 write_to=os.path.join(HERE, "flier-2up.pdf"))

print(f"flier.pdf      {TRIM_W/IN:.2f} x {TRIM_H/IN:.2f}in + {BLEED/IN:.3f}in bleed")
print(f"flier-2up.pdf  US Letter, two per sheet")
